xxxxxxxxxxxxxx_Upper_Code_xxxxxxxxxxxxxx
				<?php get_template_part('loop','single');?>
		xxxxxxxxxxxxxx_Lower_Code_xxxxxxxxxxxxxx